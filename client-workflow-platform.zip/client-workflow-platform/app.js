const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Database setup
const db = new sqlite3.Database('./database.db');

db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user' CHECK(role IN ('admin', 'user')),
    stage INTEGER CHECK(stage IN (1,2,3,4)),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Clients table
  db.run(`CREATE TABLE IF NOT EXISTS clients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Client members (many-to-many between users and clients)
  db.run(`CREATE TABLE IF NOT EXISTS client_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(client_id, user_id)
  )`);

  // Stages table
  db.run(`CREATE TABLE IF NOT EXISTS stages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id INTEGER NOT NULL,
    stage_number INTEGER NOT NULL CHECK(stage_number IN (1,2,3,4)),
    title TEXT NOT NULL,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending', 'in_progress', 'completed', 'cancelled')),
    updated_by INTEGER,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE(client_id, stage_number)
  )`);

  // Files table
  db.run(`CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stage_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    original_name TEXT NOT NULL,
    uploaded_by INTEGER NOT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (stage_id) REFERENCES stages(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE CASCADE
  )`);

  // Create admin user if not exists
  const adminEmail = 'admin@example.com';
  db.get('SELECT id FROM users WHERE email = ?', [adminEmail], (err, row) => {
    if (!row) {
      const hash = bcrypt.hashSync('admin123', 10);
      db.run(
        'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
        ['مدیر سیستم', adminEmail, hash, 'admin']
      );
    }
  });
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.use(session({
  secret: 'your-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Persian stage labels
const STAGE_LABELS = {
  1: 'سفارشات',
  2: 'طراحی',
  3: 'تولید',
  4: 'تولید و نصب'
};

const STAGE_STATUS_LABELS = {
  pending: 'در انتظار',
  in_progress: 'در حال انجام',
  completed: 'تکمیل‌شده',
  cancelled: 'لغو شده'
};

// Helper: promise wrapper for db
function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}

// Authentication middleware
function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== 'admin') {
    return res.status(403).send('دسترسی غیرمجاز');
  }
  next();
}

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, 'public/uploads');
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB
});

// Routes
app.get('/', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.render('login', { error: 'ایمیل یا رمز عبور اشتباه است' });
    }
    req.session.user = { id: user.id, name: user.name, email: user.email, role: user.role, stage: user.stage };
    res.redirect('/dashboard');
  } catch (err) {
    console.error(err);
    res.render('login', { error: 'خطا در ورود' });
  }
});

app.get('/register', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.render('register', { error: null });
});

app.post('/register', async (req, res) => {
  const { name, email, password, stage } = req.body;
  try {
    const existing = await dbGet('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) {
      return res.render('register', { error: 'این ایمیل قبلاً ثبت شده است' });
    }
    const hash = bcrypt.hashSync(password, 10);
    await dbRun(
      'INSERT INTO users (name, email, password, stage) VALUES (?, ?, ?, ?)',
      [name, email, hash, stage]
    );
    res.redirect('/login');
  } catch (err) {
    console.error(err);
    res.render('register', { error: 'خطا در ثبت‌نام' });
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// Dashboard
app.get('/dashboard', requireAuth, async (req, res) => {
  try {
    let clients;
    if (req.session.user.role === 'admin') {
      clients = await dbAll('SELECT * FROM clients ORDER BY created_at DESC');
    } else {
      clients = await dbAll(
        `SELECT c.* FROM clients c
         JOIN client_members cm ON c.id = cm.client_id
         WHERE cm.user_id = ?
         ORDER BY c.created_at DESC`,
        [req.session.user.id]
      );
    }
    res.render('dashboard', { user: req.session.user, clients, error: null });
  } catch (err) {
    console.error(err);
    res.render('dashboard', { user: req.session.user, clients: [], error: 'خطا در بارگذاری' });
  }
});

// Client detail
app.get('/clients/:id', requireAuth, async (req, res) => {
  const clientId = req.params.id;
  try {
    // Check access
    if (req.session.user.role !== 'admin') {
      const member = await dbGet(
        'SELECT id FROM client_members WHERE client_id = ? AND user_id = ?',
        [clientId, req.session.user.id]
      );
      if (!member) return res.status(403).send('شما به این کارفرما دسترسی ندارید');
    }

    const client = await dbGet('SELECT * FROM clients WHERE id = ?', [clientId]);
    if (!client) return res.status(404).send('کارفرما یافت نشد');

    const stages = await dbAll(
      `SELECT s.*, u.name as updater_name FROM stages s
       LEFT JOIN users u ON s.updated_by = u.id
       WHERE s.client_id = ? ORDER BY s.stage_number`,
      [clientId]
    );

    // If no stages exist, create them
    if (stages.length === 0) {
      for (let i = 1; i <= 4; i++) {
        await dbRun(
          'INSERT INTO stages (client_id, stage_number, title) VALUES (?, ?, ?)',
          [clientId, i, STAGE_LABELS[i]]
        );
      }
      const newStages = await dbAll(
        `SELECT s.*, u.name as updater_name FROM stages s
         LEFT JOIN users u ON s.updated_by = u.id
         WHERE s.client_id = ? ORDER BY s.stage_number`,
        [clientId]
      );
      return res.render('client-detail', {
        user: req.session.user,
        client,
        stages: newStages,
        stageLabels: STAGE_LABELS,
        statusLabels: STAGE_STATUS_LABELS,
        error: null
      });
    }

    // Get files for each stage
    for (const stage of stages) {
      stage.files = await dbAll(
        `SELECT f.*, u.name as uploader_name FROM files f
         JOIN users u ON f.uploaded_by = u.id
         WHERE f.stage_id = ? ORDER BY f.uploaded_at DESC`,
        [stage.id]
      );
    }

    res.render('client-detail', {
      user: req.session.user,
      client,
      stages,
      stageLabels: STAGE_LABELS,
      statusLabels: STAGE_STATUS_LABELS,
      error: null
    });
  } catch (err) {
    console.error(err);
    res.render('client-detail', {
      user: req.session.user,
      client: null,
      stages: [],
      stageLabels: STAGE_LABELS,
      statusLabels: STAGE_STATUS_LABELS,
      error: 'خطا در بارگذاری اطلاعات'
    });
  }
});

// Upload file to a stage
app.post('/clients/:id/stages/:stageId/files', requireAuth, upload.single('file'), async (req, res) => {
  const clientId = req.params.id;
  const stageId = req.params.stageId;

  try {
    // Check access
    if (req.session.user.role !== 'admin') {
      const member = await dbGet(
        'SELECT id FROM client_members WHERE client_id = ? AND user_id = ?',
        [clientId, req.session.user.id]
      );
      if (!member) return res.status(403).send('دسترسی غیرمجاز');
    }

    const stage = await dbGet('SELECT * FROM stages WHERE id = ? AND client_id = ?', [stageId, clientId]);
    if (!stage) return res.status(404).send('مرحله یافت نشد');

    // Only allow upload if user is admin or user's stage matches stage_number
    if (req.session.user.role !== 'admin' && req.session.user.stage != stage.stage_number) {
      return res.status(403).send('فقط اعضای همین مرحله می‌توانند فایل آپلود کنند');
    }

    if (!req.file) return res.redirect(`/clients/${clientId}?error=فایلی انتخاب نشد`);

    await dbRun(
      'INSERT INTO files (stage_id, filename, original_name, uploaded_by) VALUES (?, ?, ?, ?)',
      [stageId, req.file.filename, req.file.originalname, req.session.user.id]
    );

    // Update stage status to in_progress if pending
    if (stage.status === 'pending') {
      await dbRun(
        'UPDATE stages SET status = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        ['in_progress', req.session.user.id, stageId]
      );
    }

    res.redirect(`/clients/${clientId}`);
  } catch (err) {
    console.error(err);
    res.status(500).send('خطا در آپلود فایل');
  }
});

// Download file
app.get('/files/:id/download', requireAuth, async (req, res) => {
  try {
    const file = await dbGet(
      `SELECT f.*, s.client_id FROM files f
       JOIN stages s ON f.stage_id = s.id
       WHERE f.id = ?`,
      [req.params.id]
    );
    if (!file) return res.status(404).send('فایل یافت نشد');

    if (req.session.user.role !== 'admin') {
      const member = await dbGet(
        'SELECT id FROM client_members WHERE client_id = ? AND user_id = ?',
        [file.client_id, req.session.user.id]
      );
      if (!member) return res.status(403).send('دسترسی غیرمجاز');
    }

    const filePath = path.join(__dirname, 'public/uploads', file.filename);
    res.download(filePath, file.original_name);
  } catch (err) {
    console.error(err);
    res.status(500).send('خطا در دانلود فایل');
  }
});

// Update stage status
app.post('/clients/:id/stages/:stageId/status', requireAuth, async (req, res) => {
  const clientId = req.params.id;
  const stageId = req.params.stageId;
  const { status } = req.body;

  try {
    if (req.session.user.role !== 'admin') {
      const member = await dbGet(
        'SELECT id FROM client_members WHERE client_id = ? AND user_id = ?',
        [clientId, req.session.user.id]
      );
      if (!member) return res.status(403).send('دسترسی غیرمجاز');
    }

    await dbRun(
      'UPDATE stages SET status = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND client_id = ?',
      [status, req.session.user.id, stageId, clientId]
    );
    res.redirect(`/clients/${clientId}`);
  } catch (err) {
    console.error(err);
    res.status(500).send('خطا در به‌روزرسانی وضعیت');
  }
});

// Admin routes
app.get('/admin/clients', requireAdmin, async (req, res) => {
  try {
    const clients = await dbAll('SELECT * FROM clients ORDER BY created_at DESC');
    res.render('admin/clients', { user: req.session.user, clients, error: null });
  } catch (err) {
    console.error(err);
    res.render('admin/clients', { user: req.session.user, clients: [], error: 'خطا در بارگذاری' });
  }
});

app.post('/admin/clients', requireAdmin, async (req, res) => {
  const { name, description } = req.body;
  try {
    const result = await dbRun(
      'INSERT INTO clients (name, description) VALUES (?, ?)',
      [name, description]
    );
    // Create 4 stages automatically
    for (let i = 1; i <= 4; i++) {
      await dbRun(
        'INSERT INTO stages (client_id, stage_number, title) VALUES (?, ?, ?)',
        [result.id, i, STAGE_LABELS[i]]
      );
    }
    res.redirect('/admin/clients');
  } catch (err) {
    console.error(err);
    res.render('admin/clients', { user: req.session.user, clients: [], error: 'خطا در ایجاد کارفرما' });
  }
});

app.post('/admin/clients/:id/delete', requireAdmin, async (req, res) => {
  try {
    await dbRun('DELETE FROM clients WHERE id = ?', [req.params.id]);
    res.redirect('/admin/clients');
  } catch (err) {
    console.error(err);
    res.redirect('/admin/clients');
  }
});

app.get('/admin/users', requireAdmin, async (req, res) => {
  try {
    const users = await dbAll('SELECT id, name, email, role, stage, created_at FROM users ORDER BY created_at DESC');
    const clients = await dbAll('SELECT * FROM clients ORDER BY name');
    const memberships = await dbAll('SELECT * FROM client_members');
    res.render('admin/users', { user: req.session.user, users, clients, memberships, stageLabels: STAGE_LABELS, error: null });
  } catch (err) {
    console.error(err);
    res.render('admin/users', { user: req.session.user, users: [], clients: [], memberships: [], stageLabels: STAGE_LABELS, error: 'خطا' });
  }
});

app.post('/admin/users/:userId/clients', requireAdmin, async (req, res) => {
  const { userId } = req.params;
  const { client_id } = req.body;
  try {
    await dbRun(
      'INSERT OR IGNORE INTO client_members (client_id, user_id) VALUES (?, ?)',
      [client_id, userId]
    );
    res.redirect('/admin/users');
  } catch (err) {
    console.error(err);
    res.redirect('/admin/users');
  }
});

app.post('/admin/memberships/:id/delete', requireAdmin, async (req, res) => {
  try {
    await dbRun('DELETE FROM client_members WHERE id = ?', [req.params.id]);
    res.redirect('/admin/users');
  } catch (err) {
    console.error(err);
    res.redirect('/admin/users');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
